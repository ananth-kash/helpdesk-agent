"""IT helpdesk agent: an MCP server over a ticketing system plus a LangGraph agent that uses it."""
