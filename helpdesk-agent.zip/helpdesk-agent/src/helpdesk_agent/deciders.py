"""Deciders turn a ticket's context into a validated Decision.

LLMDecider  - Claude (or any LangChain chat model) returns JSON for the Decision
              schema; Pydantic validates it and errors go back to the model for a
              bounded number of repair attempts.
RuleDecider - keyword baseline. No API key needed, and the yardstick the LLM must
              beat on the golden set.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

from pydantic import BaseModel, ValidationError

from .prompts import REPAIR_PROMPT, TRIAGE_PROMPT
from .schemas import Action, Decision, Intent, LicensePool, Ticket, User


class KBHit(BaseModel):
    id: str
    title: str
    body: str
    score: float


class TicketContext(BaseModel):
    ticket: Ticket
    user: User
    licenses: list[str]
    pools: list[LicensePool]
    kb_hits: list[KBHit]


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    llm_calls: int = 0
    repairs: int = 0


@dataclass
class DecisionResult:
    decision: Decision
    decider: str
    usage: Usage = field(default_factory=Usage)


# --------------------------------------------------------------------------- rules

INCIDENT = re.compile(r"\b(whole|entire|everyone|nobody|all users|outage|down for|floor)\b", re.I)
ACCESS = re.compile(r"\b(password|mfa|authenticator|locked|sign in|log ?in|vpn|globalprotect)\b", re.I)
LICENSE = re.compile(r"\b(license|licence|seat|access to|need|get)\b", re.I)
KB_MIN_SCORE = 0.12


class RuleDecider:
    name = "rules"

    def decide(self, ctx: TicketContext) -> DecisionResult:
        text = f"{ctx.ticket.short_description}. {ctx.ticket.description}"
        top = ctx.kb_hits[0] if ctx.kb_hits else None
        product = next((p.product for p in ctx.pools if p.product.lower() in text.lower()), None)
        if product is None:  # also match the first word, e.g. "Salesforce"
            product = next((p.product for p in ctx.pools
                            if re.search(rf"\b{re.escape(p.product.split()[0])}\b", text, re.I)), None)

        if INCIDENT.search(text):
            d = Decision(intent=Intent.INCIDENT, confidence=0.75,
                         reply_to_user="Thanks for reporting this. It looks like it affects several people, "
                                       "so we've raised it with the on-call team and will update you here.",
                         actions=[Action(type="escalate", reason="Possible multi-user incident")])
        elif product and LICENSE.search(text):
            d = Decision(intent=Intent.LICENSE_REQUEST, confidence=0.8,
                         reply_to_user=f"You've been given a {product} license. It can take up to 15 minutes "
                                       f"to appear when you sign in.",
                         cited_kb=["KB004"] if any(h.id == "KB004" for h in ctx.kb_hits) else [],
                         actions=[Action(type="assign_license", product=product, reason="User requested a seat"),
                                  Action(type="resolve_ticket", reason="License assigned")])
        elif top and top.score >= KB_MIN_SCORE:
            intent = Intent.ACCESS_ISSUE if ACCESS.search(text) else Intent.HOW_TO
            d = Decision(intent=intent, confidence=0.75,
                         reply_to_user=f"This should fix it ({top.title}): {top.body}",
                         cited_kb=[top.id],
                         actions=[Action(type="resolve_ticket", reason=f"Answered by {top.id}")])
        else:
            d = Decision(intent=Intent.OTHER, confidence=0.3,
                         reply_to_user="Thanks, an engineer will look at this and get back to you.",
                         actions=[Action(type="escalate", reason="No confident match")])
        return DecisionResult(decision=d, decider=self.name)


# --------------------------------------------------------------------------- llm

_FENCE = re.compile(r"^```(?:json)?\s*|\s*```$", re.MULTILINE)


def parse_decision(text: str) -> Decision:
    cleaned = _FENCE.sub("", text.strip())
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("No JSON object in model output")
    return Decision.model_validate(json.loads(cleaned[start : end + 1]))


def render_prompt(ctx: TicketContext) -> str:
    return TRIAGE_PROMPT.format(
        ticket=f"{ctx.ticket.number}: {ctx.ticket.short_description}\n{ctx.ticket.description}",
        user=f"{ctx.user.name} ({ctx.user.id}), {ctx.user.department}",
        licenses=", ".join(ctx.licenses) or "none",
        pools="\n".join(f"- {p.product}: {p.available} free of {p.total_seats}; "
                        f"departments: {', '.join(p.allowed_departments) or 'any'}" for p in ctx.pools),
        kb="\n\n".join(f"[{h.id}] {h.title} (score {h.score})\n{h.body}" for h in ctx.kb_hits) or "none found",
    )


class LLMDecider:
    name = "llm"

    def __init__(self, model, max_repairs: int = 2):
        self.model = model
        self.max_repairs = max_repairs

    def decide(self, ctx: TicketContext) -> DecisionResult:
        from langchain_core.messages import AIMessage, HumanMessage

        usage = Usage()
        messages = [HumanMessage(render_prompt(ctx))]
        error: Exception | None = None
        for _ in range(self.max_repairs + 1):
            reply = self.model.invoke(messages)
            usage.llm_calls += 1
            meta = getattr(reply, "usage_metadata", None) or {}
            usage.input_tokens += meta.get("input_tokens", 0)
            usage.output_tokens += meta.get("output_tokens", 0)
            try:
                return DecisionResult(parse_decision(reply.content), self.name, usage)
            except (ValueError, ValidationError) as exc:
                error = exc
                usage.repairs += 1
                messages += [AIMessage(reply.content), HumanMessage(REPAIR_PROMPT.format(error=str(exc)[:500]))]
        raise RuntimeError(f"Model output still invalid after {self.max_repairs} repairs: {error}")


def default_llm():
    """Claude via LangChain. Needs ANTHROPIC_API_KEY; override the model with HELPDESK_MODEL."""
    import os

    from langchain_anthropic import ChatAnthropic

    return ChatAnthropic(model=os.environ.get("HELPDESK_MODEL", "claude-haiku-5-5"), temperature=0, max_tokens=800)
