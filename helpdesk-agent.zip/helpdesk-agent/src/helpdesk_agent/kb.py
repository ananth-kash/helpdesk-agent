"""Knowledge-base retrieval.

A small vector index over KB articles: each article is embedded as a TF-IDF vector
(word 1-2 grams), queries are embedded the same way, and results are ranked by
cosine similarity. It needs no model download or API key. Swap `embed` for a
neural embedding model (and the matrix for pgvector) without touching callers.
"""

from __future__ import annotations

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from .schemas import KBArticle


class KBIndex:
    def __init__(self, articles: list[KBArticle]):
        self.articles = articles
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words="english", sublinear_tf=True)
        corpus = [f"{a.title}. {a.title}. {a.body}" for a in articles]  # title counts double
        self.matrix = self.vectorizer.fit_transform(corpus) if articles else None

    def search(self, query: str, k: int = 3, min_score: float = 0.05) -> list[tuple[KBArticle, float]]:
        if self.matrix is None:
            return []
        q = self.vectorizer.transform([query])
        scores = (self.matrix @ q.T).toarray().ravel()  # rows are L2-normalised, so this is cosine
        order = np.argsort(-scores)[:k]
        return [(self.articles[i], round(float(scores[i]), 3)) for i in order if scores[i] >= min_score]

    def get(self, article_id: str) -> KBArticle | None:
        return next((a for a in self.articles if a.id == article_id), None)
