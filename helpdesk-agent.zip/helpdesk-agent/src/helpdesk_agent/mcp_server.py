"""MCP server for the IT helpdesk.

Any MCP client (this repo's agent, Claude Code, Cursor, Claude Desktop) gets:

Tools      list_open_tickets, get_ticket, get_user_profile, list_license_pools, search_kb   (read-only)
           assign_license, add_work_note, resolve_ticket                                    (writes)
Resource   kb://{article_id}
Prompt     triage_ticket

Every write needs a named human approver, and assign_license re-runs the license
policy on the server, so the guardrails hold for every client, not only this agent.

Run over stdio:  python -m helpdesk_agent.mcp_server
"""

from __future__ import annotations

from mcp.server.mcpserver import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from mcp.types import ToolAnnotations
from pydantic import BaseModel

from .backends import Backend, NotFound, backend_from_env
from .kb import KBIndex
from .policy import check_license
from .prompts import TRIAGE_PROMPT
from .schemas import KBArticle, LicensePool, Ticket, User


class UserProfile(BaseModel):
    user: User
    licenses: list[str]


class KBHit(BaseModel):
    id: str
    title: str
    body: str
    score: float


class WriteReceipt(BaseModel):
    ok: bool
    detail: str


def build_server(backend: Backend) -> MCPServer:
    server = MCPServer(name="it-helpdesk",
                       instructions="IT helpdesk tickets, users, software licenses and knowledge base. "
                                    "Write tools require a named human approver.")
    kb_index = KBIndex(backend.kb_articles())
    ro = ToolAnnotations(readOnlyHint=True, openWorldHint=False)
    write = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=False)

    def _need_approver(approved_by: str) -> None:
        if not approved_by or not approved_by.strip():
            raise ToolError("Refused: this write needs a named human approver")

    def _wrap(fn, *args):
        try:
            return fn(*args)
        except NotFound as exc:
            raise ToolError(str(exc)) from exc

    @server.tool(annotations=ro)
    def list_open_tickets() -> list[Ticket]:
        """List tickets that are not yet resolved."""
        return backend.list_open_tickets()

    @server.tool(annotations=ro)
    def get_ticket(number: str) -> Ticket:
        """Get one ticket by number, e.g. INC1001."""
        return _wrap(backend.get_ticket, number)

    @server.tool(annotations=ro)
    def get_user_profile(user_id: str) -> UserProfile:
        """Get a user's department and the software licenses they already hold."""
        return UserProfile(user=_wrap(backend.get_user, user_id), licenses=backend.user_licenses(user_id))

    @server.tool(annotations=ro)
    def list_license_pools() -> list[LicensePool]:
        """List licensable products with seat counts and department restrictions."""
        return backend.license_pools()

    @server.tool(annotations=ro)
    def search_kb(query: str, k: int = 3) -> list[KBHit]:
        """Semantic search over the knowledge base. Returns the best articles with similarity scores."""
        return [KBHit(id=a.id, title=a.title, body=a.body, score=s) for a, s in kb_index.search(query, k=k)]

    @server.tool(annotations=write)
    def assign_license(ticket_number: str, user_id: str, product: str, approved_by: str) -> WriteReceipt:
        """Assign a software seat to a user. Re-checks catalog, department and seat rules on the server."""
        _need_approver(approved_by)
        user = _wrap(backend.get_user, user_id)
        why = check_license(user, product, backend.user_licenses(user_id), backend.license_pools())
        if why:
            raise ToolError(f"Refused by license policy: {why}")
        seat = backend.assign_license(user_id, product)
        backend.add_work_note(ticket_number, f"Assigned {product} to {user_id} (seat {seat}). Approved by {approved_by}.")
        return WriteReceipt(ok=True, detail=f"seat {seat}")

    @server.tool(annotations=write)
    def add_work_note(ticket_number: str, note: str, approved_by: str) -> WriteReceipt:
        """Add an internal work note to a ticket."""
        _need_approver(approved_by)
        _wrap(backend.get_ticket, ticket_number)
        backend.add_work_note(ticket_number, f"{note}\n(Approved by {approved_by})")
        return WriteReceipt(ok=True, detail="note added")

    @server.tool(annotations=write)
    def resolve_ticket(ticket_number: str, resolution: str, approved_by: str) -> WriteReceipt:
        """Resolve a ticket with a reply to the user."""
        _need_approver(approved_by)
        if len(resolution.strip()) < 10:
            raise ToolError("Refused: resolution text is too short to send to a user")
        _wrap(backend.get_ticket, ticket_number)
        backend.resolve_ticket(ticket_number, f"{resolution}\n(Approved by {approved_by})")
        return WriteReceipt(ok=True, detail="resolved")

    @server.resource("kb://{article_id}", mime_type="text/plain")
    def kb_article(article_id: str) -> str:
        """Full text of one knowledge-base article."""
        article: KBArticle | None = kb_index.get(article_id)
        if article is None:
            raise ToolError(f"No KB article {article_id}")
        return f"{article.title}\n\n{article.body}"

    @server.prompt()
    def triage_ticket(ticket: str, user: str, licenses: str, pools: str, kb: str) -> str:
        """The prompt the agent uses to decide on a ticket; reusable from any MCP client."""
        return TRIAGE_PROMPT.format(ticket=ticket, user=user, licenses=licenses, pools=pools, kb=kb)

    return server


def main() -> None:
    build_server(backend_from_env()).run("stdio")


if __name__ == "__main__":
    main()
