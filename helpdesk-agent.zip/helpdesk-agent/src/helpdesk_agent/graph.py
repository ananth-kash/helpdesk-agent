"""LangGraph planner-executor that works through the open ticket queue.

    plan ─► gather ─► decide ─► guard ─► approve (interrupt) ─► execute ─► record ─┐
              ▲                                                                    │
              └──────────────────────── more tickets? ◄────────────────────────────┘
                                               no ─► report

gather   reads ticket, requester, licenses, catalog and KB hits through MCP tools
decide   LLM (or rule) decider -> validated Decision; falls back to rules on failure
guard    deterministic policy: blocked actions become an escalation with the reason
approve  pauses for a named human, who can approve, reject or edit the reply
execute  performs the approved writes through MCP; a refused write becomes an escalation
"""

from __future__ import annotations

from typing import Any, TypedDict

from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from .deciders import DecisionResult, KBHit, RuleDecider, TicketContext
from .policy import apply_policy
from .schemas import Decision, LicensePool, Ticket, User


class State(TypedDict, total=False):
    queue: list[str]
    index: int
    ctx: dict | None
    decision: dict | None
    decider: str | None
    plan: dict | None        # {"actions": [...allowed], "blocked": [...reasons]}
    approval: dict | None
    outcomes: list[dict]
    report: str


def _deps(config: RunnableConfig):
    c = config["configurable"]
    return c["mcp"], c["decider"], c["tracer"]


async def _tool(client, name: str, args: dict | None = None) -> Any:
    result = await client.call_tool(name, args or {})
    if result.is_error:
        raise RuntimeError(result.content[0].text if result.content else f"{name} failed")
    data = result.structured_content
    return data["result"] if isinstance(data, dict) and set(data) == {"result"} else data


# --------------------------------------------------------------------------- nodes

async def plan(state: State, config: RunnableConfig) -> State:
    client, _, tracer = _deps(config)
    with tracer.span("plan"):
        tickets = await _tool(client, "list_open_tickets")
    return {"queue": [t["number"] for t in tickets], "index": 0, "outcomes": []}


def more(state: State) -> str:
    return "gather" if state["index"] < len(state["queue"]) else "report"


async def gather(state: State, config: RunnableConfig) -> State:
    client, _, tracer = _deps(config)
    number = state["queue"][state["index"]]
    with tracer.span("gather", number):
        ticket = await _tool(client, "get_ticket", {"number": number})
        profile = await _tool(client, "get_user_profile", {"user_id": ticket["caller"]})
        pools = await _tool(client, "list_license_pools")
        hits = await _tool(client, "search_kb", {"query": f"{ticket['short_description']}. {ticket['description']}"})
    ctx = TicketContext(ticket=Ticket(**ticket), user=User(**profile["user"]), licenses=profile["licenses"],
                        pools=[LicensePool(**p) for p in pools], kb_hits=[KBHit(**h) for h in hits])
    return {"ctx": ctx.model_dump(mode="json")}


async def decide(state: State, config: RunnableConfig) -> State:
    _, decider, tracer = _deps(config)
    ctx = TicketContext.model_validate(state["ctx"])
    try:
        with tracer.span("decide", ctx.ticket.number) as span:
            out: DecisionResult = decider.decide(ctx)
            span.input_tokens, span.output_tokens = out.usage.input_tokens, out.usage.output_tokens
            span.llm_calls = out.usage.llm_calls
            span.extra = {"decider": out.decider, "repairs": out.usage.repairs}
    except Exception:
        with tracer.span("decide_fallback", ctx.ticket.number):
            out = RuleDecider().decide(ctx)
            out.decider = "rules-fallback"
    return {"decision": out.decision.model_dump(mode="json"), "decider": out.decider}


def guard(state: State, config: RunnableConfig) -> State:
    _, _, tracer = _deps(config)
    ctx = TicketContext.model_validate(state["ctx"])
    decision = Decision.model_validate(state["decision"])
    with tracer.span("guard", ctx.ticket.number):
        checked = apply_policy(decision, ctx.user, ctx.licenses, ctx.pools, {h.id for h in ctx.kb_hits})
    return {"plan": {"actions": [c.action.model_dump() for c in checked if c.allowed],
                     "blocked": [c.reason for c in checked if not c.allowed]}}


def approve(state: State) -> State:
    ctx, decision = state["ctx"], state["decision"]
    answer = interrupt({
        "ticket": ctx["ticket"]["number"],
        "summary": ctx["ticket"]["short_description"],
        "requester": f"{ctx['user']['name']} ({ctx['user']['department']})",
        "intent": decision["intent"], "confidence": decision["confidence"],
        "reply_to_user": decision["reply_to_user"],
        "actions": state["plan"]["actions"],
        "blocked_by_policy": state["plan"]["blocked"],
    })
    return {"approval": answer}


async def execute(state: State, config: RunnableConfig) -> State:
    client, _, tracer = _deps(config)
    ctx, decision, approval = state["ctx"], state["decision"], state["approval"] or {}
    number, user_id = ctx["ticket"]["number"], ctx["user"]["id"]
    done, errors = [], []
    if not (approval.get("approved") and approval.get("approver")):
        return {"approval": {**approval, "approved": False}, "decision": decision,
                "plan": {**state["plan"], "executed": [], "errors": []}}

    who, reply = approval["approver"], approval.get("reply") or decision["reply_to_user"]
    actions = state["plan"]["actions"]
    with tracer.span("execute", number):
        for a in actions:
            try:
                if a["type"] == "assign_license":
                    await _tool(client, "assign_license", {"ticket_number": number, "user_id": user_id,
                                                           "product": a["product"], "approved_by": who})
                    done.append(f"assigned {a['product']}")
                elif a["type"] == "resolve_ticket":
                    if errors:  # don't tell the user it's fixed if an earlier step failed
                        continue
                    await _tool(client, "resolve_ticket", {"ticket_number": number, "resolution": reply,
                                                           "approved_by": who})
                    done.append("resolved")
                elif a["type"] == "escalate":
                    await _tool(client, "add_work_note", {"ticket_number": number, "approved_by": who,
                                                          "note": f"Escalated: {a['reason']}\nDraft reply: {reply}"})
                    done.append("escalated")
            except Exception as exc:
                errors.append(str(exc))
        if errors and "escalated" not in done:  # recovery: hand back to a human with the reason
            await _tool(client, "add_work_note", {"ticket_number": number, "approved_by": who,
                                                  "note": "Escalated after failed action: " + "; ".join(errors)})
            done.append("escalated")
    return {"plan": {**state["plan"], "executed": done, "errors": errors}}


def record(state: State) -> State:
    ctx, d, p = state["ctx"], state["decision"], state["plan"]
    outcome = {"ticket": ctx["ticket"]["number"], "summary": ctx["ticket"]["short_description"],
               "intent": d["intent"], "confidence": d["confidence"], "decider": state["decider"],
               "proposed": [a["type"] + (f":{a['product']}" if a.get("product") else "") for a in p["actions"]],
               "blocked": p["blocked"], "executed": p.get("executed", []), "errors": p.get("errors", []),
               "approved": bool((state.get("approval") or {}).get("approved"))}
    return {"outcomes": state["outcomes"] + [outcome], "index": state["index"] + 1,
            "ctx": None, "decision": None, "plan": None, "approval": None}


def report(state: State, config: RunnableConfig) -> State:
    _, _, tracer = _deps(config)
    lines = ["# Helpdesk run", "", "| Ticket | Summary | Intent | Conf. | Decider | Done | Policy blocks |",
             "|---|---|---|---|---|---|---|"]
    for o in state["outcomes"]:
        done = ", ".join(o["executed"]) if o["approved"] else "rejected by approver"
        lines.append(f"| {o['ticket']} | {o['summary']} | {o['intent']} | {o['confidence']:.2f} | {o['decider']} | "
                     f"{done} | {'; '.join(o['blocked']) or '-'} |")
    s = tracer.summary()
    lines += ["", f"Trace: {s['spans']} spans, {s['total_ms']} ms, {s['llm_calls']} LLM calls, "
                  f"{s['input_tokens']} in / {s['output_tokens']} out tokens"]
    return {"report": "\n".join(lines)}


def build_graph(checkpointer=None):
    g = StateGraph(State)
    for name, fn in [("plan", plan), ("gather", gather), ("decide", decide), ("guard", guard),
                     ("approve", approve), ("execute", execute), ("record", record), ("report", report)]:
        g.add_node(name, fn)
    g.add_edge(START, "plan")
    g.add_conditional_edges("plan", more, ["gather", "report"])
    g.add_edge("gather", "decide")
    g.add_edge("decide", "guard")
    g.add_edge("guard", "approve")
    g.add_edge("approve", "execute")
    g.add_edge("execute", "record")
    g.add_conditional_edges("record", more, ["gather", "report"])
    g.add_edge("report", END)
    return g.compile(checkpointer=checkpointer or InMemorySaver())
