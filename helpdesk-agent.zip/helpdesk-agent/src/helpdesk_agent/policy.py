"""Deterministic guardrails applied to every proposed action before a human sees it.

The model proposes; policy disposes. Anything that fails a rule is turned into an
escalation with the reason, so the agent never asks a human to approve something
the business rules already forbid.
"""

from __future__ import annotations

from dataclasses import dataclass

from .schemas import Action, Decision, Intent, LicensePool, User

MIN_CONFIDENCE_TO_RESOLVE = 0.7


@dataclass
class Checked:
    action: Action
    allowed: bool
    reason: str = ""


def check_license(user: User, product: str | None, owned: list[str], pools: list[LicensePool]) -> str | None:
    """Return why a license can't be assigned, or None if it can."""
    pool = next((p for p in pools if product and p.product.lower() == product.lower()), None)
    if pool is None:
        return f"'{product}' is not in the license catalog"
    if pool.product in owned:
        return f"{user.name} already has {pool.product}"
    if pool.allowed_departments and user.department not in pool.allowed_departments:
        return f"{pool.product} is limited to {', '.join(pool.allowed_departments)}; {user.name} is in {user.department}"
    if pool.available <= 0:
        return f"No free {pool.product} seats ({pool.used_seats}/{pool.total_seats} used)"
    return None


def apply_policy(decision: Decision, user: User, owned: list[str], pools: list[LicensePool],
                 known_kb: set[str]) -> list[Checked]:
    checked: list[Checked] = []
    citations_ok = bool(decision.cited_kb) and all(c in known_kb for c in decision.cited_kb)
    for action in decision.actions:
        if action.type == "assign_license":
            why = check_license(user, action.product, owned, pools)
            checked.append(Checked(action, why is None, why or ""))
        elif action.type == "resolve_ticket":
            if any(not c.allowed and c.action.type == "assign_license" for c in checked):
                checked.append(Checked(action, False, "Can't resolve: the license it depends on was blocked"))
            elif decision.intent is Intent.INCIDENT:
                checked.append(Checked(action, False, "Incidents affecting many users must be escalated"))
            elif decision.confidence < MIN_CONFIDENCE_TO_RESOLVE:
                checked.append(Checked(action, False, f"Confidence {decision.confidence:.2f} is below "
                                                      f"{MIN_CONFIDENCE_TO_RESOLVE}"))
            elif not citations_ok and not any(c.allowed and c.action.type == "assign_license" for c in checked):
                checked.append(Checked(action, False, "Resolution isn't grounded in a known KB article"))
            else:
                checked.append(Checked(action, True))
        else:  # escalate is always allowed
            checked.append(Checked(action, True))

    blocked = [c for c in checked if not c.allowed]
    if blocked and not any(c.allowed and c.action.type == "escalate" for c in checked):
        reasons = "; ".join(c.reason for c in blocked)
        checked.append(Checked(Action(type="escalate", reason=f"Policy blocked: {reasons}"), True))
    return checked
