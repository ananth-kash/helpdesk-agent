"""Minimal per-node tracing: latency, token usage and errors, written as JSONL."""

from __future__ import annotations

import json
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class Span:
    node: str
    item: str | None
    ms: float
    input_tokens: int = 0
    output_tokens: int = 0
    llm_calls: int = 0
    error: str | None = None
    extra: dict = field(default_factory=dict)


class Tracer:
    def __init__(self) -> None:
        self.spans: list[Span] = []

    @contextmanager
    def span(self, node: str, item: str | None = None):
        record = Span(node=node, item=item, ms=0.0)
        start = time.perf_counter()
        try:
            yield record
        except Exception as exc:
            record.error = f"{type(exc).__name__}: {exc}"[:300]
            raise
        finally:
            record.ms = round((time.perf_counter() - start) * 1000, 2)
            self.spans.append(record)

    def summary(self) -> dict:
        by_node: dict[str, dict] = {}
        for s in self.spans:
            n = by_node.setdefault(s.node, {"calls": 0, "total_ms": 0.0, "errors": 0})
            n["calls"] += 1
            n["total_ms"] = round(n["total_ms"] + s.ms, 2)
            n["errors"] += int(s.error is not None)
        return {
            "spans": len(self.spans),
            "total_ms": round(sum(s.ms for s in self.spans), 2),
            "input_tokens": sum(s.input_tokens for s in self.spans),
            "output_tokens": sum(s.output_tokens for s in self.spans),
            "llm_calls": sum(s.llm_calls for s in self.spans),
            "by_node": by_node,
        }

    def write(self, path: str | Path) -> None:
        with open(path, "w") as fh:
            for s in self.spans:
                fh.write(json.dumps(asdict(s)) + "\n")
