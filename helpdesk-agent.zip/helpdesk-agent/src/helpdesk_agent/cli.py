"""Command line entry point.

    helpdesk-agent run                       work the open queue, asking you before every write
    helpdesk-agent run --decider rules       no API key needed
    helpdesk-agent run --approver "Ananth"   pre-approve as a named person (batch mode)
    helpdesk-agent reset                     re-seed the demo database
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import uuid

import mcp
from langgraph.types import Command
from mcp import StdioServerParameters

from .backends.demo import DemoBackend
from .deciders import LLMDecider, RuleDecider, default_llm
from .graph import build_graph
from .tracing import Tracer


def _show(req: dict) -> None:
    print(f"\n── {req['ticket']}: {req['summary']}  [{req['requester']}]")
    print(f"   intent={req['intent']} confidence={req['confidence']:.2f}")
    for a in req["actions"]:
        print(f"   will {a['type']}" + (f" {a['product']}" if a.get("product") else "") + f"  ({a['reason']})")
    for b in req["blocked_by_policy"]:
        print(f"   blocked by policy: {b}")
    print(f"   reply: {req['reply_to_user']}")


async def run_queue(decider, server, approver: str | None = None, ask=input,
                    trace_path: str | None = None) -> dict:
    """Run the agent against an MCP server (MCPServer object, transport or stdio params)."""
    tracer = Tracer()
    graph = build_graph()
    async with mcp.Client(server) as client:
        config = {"configurable": {"thread_id": uuid.uuid4().hex, "mcp": client,
                                   "decider": decider, "tracer": tracer}}
        result = await graph.ainvoke({}, config)
        while "__interrupt__" in result:
            req = result["__interrupt__"][0].value
            if approver:
                answer = {"approved": True, "approver": approver}
            else:
                _show(req)
                choice = ask("   approve / edit reply / reject? [a/e/R] ").strip().lower()
                answer = {"approved": False}
                if choice in ("a", "e"):
                    name = ask("   your name: ").strip()
                    reply = ask("   new reply: ").strip() if choice == "e" else None
                    answer = {"approved": bool(name), "approver": name, "reply": reply}
            result = await graph.ainvoke(Command(resume=answer), config)
    if trace_path:
        tracer.write(trace_path)
    result["trace_summary"] = tracer.summary()
    return result


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="helpdesk-agent")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("reset")
    run = sub.add_parser("run")
    run.add_argument("--decider", choices=["llm", "rules"], default="llm")
    run.add_argument("--approver")
    run.add_argument("--trace", default="trace.jsonl")
    run.add_argument("--json", action="store_true", help="print outcomes as JSON")
    args = p.parse_args(argv)

    if args.cmd == "reset":
        DemoBackend(os.environ.get("HELPDESK_DB", "helpdesk_demo.db")).seed()
        print("Demo data reset")
        return

    os.environ.setdefault("HELPDESK_DB", os.path.abspath("helpdesk_demo.db"))
    server = StdioServerParameters(command=sys.executable, args=["-m", "helpdesk_agent.mcp_server"],
                                   env=dict(os.environ))
    decider = LLMDecider(default_llm()) if args.decider == "llm" else RuleDecider()
    result = asyncio.run(run_queue(decider, server, approver=args.approver, trace_path=args.trace))
    print(json.dumps(result["outcomes"], indent=2) if args.json else result["report"])


if __name__ == "__main__":
    main()
