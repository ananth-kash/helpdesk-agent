"""Data models shared by the backends, the MCP server and the agent."""

from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field


# ----------------------------------------------------------------- system of record

class Ticket(BaseModel):
    number: str
    caller: str            # user id, e.g. "u.priya"
    short_description: str
    description: str
    state: str = "new"     # new | in_progress | resolved


class User(BaseModel):
    id: str
    name: str
    department: str
    email: str


class LicensePool(BaseModel):
    product: str
    total_seats: int
    used_seats: int
    allowed_departments: list[str]  # empty = any department

    @property
    def available(self) -> int:
        return self.total_seats - self.used_seats


class KBArticle(BaseModel):
    id: str
    title: str
    body: str


# ----------------------------------------------------------------- agent output

class Intent(str, Enum):
    LICENSE_REQUEST = "license_request"  # needs a software seat
    HOW_TO = "how_to"                    # answerable from the knowledge base
    ACCESS_ISSUE = "access_issue"        # login, password, MFA, VPN
    INCIDENT = "incident"                # something is broken for many people
    OTHER = "other"


class Action(BaseModel):
    type: Literal["assign_license", "resolve_ticket", "escalate"]
    product: str | None = None           # for assign_license
    reason: str = Field(min_length=3, max_length=300)


class Decision(BaseModel):
    """What the decider must return for one ticket (validated structured output)."""

    intent: Intent
    confidence: float = Field(ge=0, le=1)
    reply_to_user: str = Field(min_length=10, max_length=1200)
    cited_kb: list[str] = Field(default_factory=list, max_length=3)
    actions: list[Action] = Field(default_factory=list, max_length=3)
