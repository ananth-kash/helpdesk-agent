"""ServiceNow backend over the REST Table API.

Works with a free ServiceNow Personal Developer Instance (developer.servicenow.com).

    HELPDESK_BACKEND=servicenow
    SERVICENOW_INSTANCE=dev12345           # -> https://dev12345.service-now.com
    SERVICENOW_USER=admin
    SERVICENOW_PASSWORD=...

Tables used
    incident                  tickets (number, caller_id, short_description, description, state)
    sys_user                  users (user_name, name, department, email)
    kb_knowledge              published knowledge articles
    alm_license               software license pools (needs Software Asset Management)
    alm_entitlement_user      seat assignments (needs Software Asset Management)

Licenses are optional: if the alm_* tables aren't available, license reads come back
empty and assign_license raises, so the agent escalates license requests instead.
"""

from __future__ import annotations

import html
import os
import re

import httpx

from ..schemas import KBArticle, LicensePool, Ticket, User
from .base import NotFound

STATE = {"1": "new", "2": "in_progress", "3": "on_hold", "6": "resolved", "7": "closed", "8": "canceled"}


def _strip_html(text: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", " ", text or "")).strip()


class ServiceNowBackend:
    def __init__(self, base_url: str, auth: tuple[str, str] | None = None,
                 transport: httpx.BaseTransport | None = None):
        self.client = httpx.Client(base_url=base_url.rstrip("/") + "/api/now/table", auth=auth,
                                   headers={"Accept": "application/json"}, timeout=20,
                                   transport=transport)

    @classmethod
    def from_env(cls) -> "ServiceNowBackend":
        instance = os.environ["SERVICENOW_INSTANCE"]
        base = instance if instance.startswith("http") else f"https://{instance}.service-now.com"
        return cls(base, auth=(os.environ["SERVICENOW_USER"], os.environ["SERVICENOW_PASSWORD"]))

    # helpers -------------------------------------------------------------
    def _get(self, table: str, query: str = "", fields: str = "", limit: int = 100) -> list[dict]:
        params = {"sysparm_query": query, "sysparm_limit": limit, "sysparm_display_value": "true",
                  "sysparm_exclude_reference_link": "true"}
        if fields:
            params["sysparm_fields"] = fields
        r = self.client.get(f"/{table}", params=params)
        r.raise_for_status()
        return r.json()["result"]

    def _one(self, table: str, query: str, fields: str = "") -> dict:
        rows = self._get(table, query, fields, limit=1)
        if not rows:
            raise NotFound(f"No {table} record for {query}")
        return rows[0]

    def _sys_id(self, table: str, query: str) -> str:
        r = self.client.get(f"/{table}", params={"sysparm_query": query, "sysparm_fields": "sys_id",
                                                 "sysparm_limit": 1})
        r.raise_for_status()
        rows = r.json()["result"]
        if not rows:
            raise NotFound(f"No {table} record for {query}")
        return rows[0]["sys_id"]

    def _ticket(self, row: dict) -> Ticket:
        caller = row.get("caller_id.user_name") or row.get("caller_id") or ""
        return Ticket(number=row["number"], caller=caller, short_description=row.get("short_description", ""),
                      description=row.get("description", ""),
                      state=STATE.get(str(row.get("state")), str(row.get("state", "")).lower()))

    # reads ---------------------------------------------------------------
    _TICKET_FIELDS = "number,caller_id.user_name,short_description,description,state"

    def list_open_tickets(self) -> list[Ticket]:
        rows = self._get("incident", "active=true^stateIN1,2^ORDERBYnumber", self._TICKET_FIELDS, limit=50)
        return [self._ticket(r) for r in rows]

    def get_ticket(self, number: str) -> Ticket:
        return self._ticket(self._one("incident", f"number={number}", self._TICKET_FIELDS))

    def get_user(self, user_id: str) -> User:
        r = self._one("sys_user", f"user_name={user_id}", "user_name,name,department,email")
        return User(id=r["user_name"], name=r["name"], department=r.get("department") or "", email=r.get("email") or "")

    def user_licenses(self, user_id: str) -> list[str]:
        try:
            rows = self._get("alm_entitlement_user", f"assigned_to.user_name={user_id}", "licensed_by")
        except httpx.HTTPStatusError:
            return []
        return sorted({r["licensed_by"] for r in rows if r.get("licensed_by")})

    def license_pools(self) -> list[LicensePool]:
        try:
            rows = self._get("alm_license", "", "display_name,rights,allocations_used")
        except httpx.HTTPStatusError:
            return []
        return [LicensePool(product=r["display_name"], total_seats=int(r.get("rights") or 0),
                            used_seats=int(r.get("allocations_used") or 0), allowed_departments=[])
                for r in rows]

    def kb_articles(self) -> list[KBArticle]:
        rows = self._get("kb_knowledge", "workflow_state=published", "number,short_description,text", limit=500)
        return [KBArticle(id=r["number"], title=r["short_description"], body=_strip_html(r.get("text", "")))
                for r in rows]

    # writes --------------------------------------------------------------
    def assign_license(self, user_id: str, product: str) -> str:
        license_id = self._sys_id("alm_license", f"display_name={product}")
        user_sys_id = self._sys_id("sys_user", f"user_name={user_id}")
        r = self.client.post("/alm_entitlement_user", json={"licensed_by": license_id, "assigned_to": user_sys_id})
        r.raise_for_status()
        return r.json()["result"]["sys_id"]

    def resolve_ticket(self, number: str, resolution: str) -> None:
        sys_id = self._sys_id("incident", f"number={number}")
        r = self.client.patch(f"/incident/{sys_id}", json={
            "state": "6", "close_code": "Solution provided", "close_notes": resolution})
        r.raise_for_status()

    def add_work_note(self, number: str, note: str) -> None:
        sys_id = self._sys_id("incident", f"number={number}")
        r = self.client.patch(f"/incident/{sys_id}", json={"work_notes": note})
        r.raise_for_status()
