import os

from .base import Backend, NotFound
from .demo import DemoBackend


def backend_from_env() -> Backend:
    """HELPDESK_BACKEND=servicenow uses SERVICENOW_INSTANCE / _USER / _PASSWORD; default is the demo DB."""
    if os.environ.get("HELPDESK_BACKEND", "demo") == "servicenow":
        from .servicenow import ServiceNowBackend

        return ServiceNowBackend.from_env()
    return DemoBackend(os.environ.get("HELPDESK_DB", "helpdesk_demo.db"))


__all__ = ["Backend", "NotFound", "DemoBackend", "backend_from_env"]
