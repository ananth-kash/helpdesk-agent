"""SQLite demo backend, seeded with a small company's tickets, users, licenses and KB."""

from __future__ import annotations

import json
import sqlite3
import uuid
from pathlib import Path

from ..schemas import KBArticle, LicensePool, Ticket, User
from .base import NotFound

SCHEMA = """
CREATE TABLE IF NOT EXISTS users    (id TEXT PRIMARY KEY, name TEXT, department TEXT, email TEXT);
CREATE TABLE IF NOT EXISTS tickets  (number TEXT PRIMARY KEY, caller TEXT, short_description TEXT,
                                     description TEXT, state TEXT, resolution TEXT);
CREATE TABLE IF NOT EXISTS notes    (number TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS pools    (product TEXT PRIMARY KEY, total INTEGER, allowed TEXT);
CREATE TABLE IF NOT EXISTS seats    (id TEXT PRIMARY KEY, product TEXT, user_id TEXT);
CREATE TABLE IF NOT EXISTS kb       (id TEXT PRIMARY KEY, title TEXT, body TEXT);
"""

USERS = [
    ("u.priya", "Priya Nair", "Design", "priya@example.com"),
    ("u.rahul", "Rahul Mehta", "Sales", "rahul@example.com"),
    ("u.sara", "Sara Thomas", "Finance", "sara@example.com"),
    ("u.arjun", "Arjun Rao", "Engineering", "arjun@example.com"),
    ("u.meera", "Meera Iyer", "Sales", "meera@example.com"),
]

POOLS = [  # product, total seats, departments allowed ([] = anyone)
    ("Figma", 3, ["Design", "Engineering"]),
    ("Adobe Acrobat Pro", 10, []),
    ("Tableau", 2, ["Finance", "Sales"]),
    ("Salesforce Sales Cloud", 4, ["Sales"]),
    ("JetBrains IntelliJ", 5, ["Engineering"]),
]

SEATS = [("Figma", "u.arjun"), ("Figma", "u.x1"), ("Tableau", "u.x2"), ("Tableau", "u.x3"),
         ("Salesforce Sales Cloud", "u.rahul"), ("Adobe Acrobat Pro", "u.sara")]

KB = [
    ("KB001", "Connect to the company VPN",
     "Install GlobalProtect from the Software Center, open it, enter portal vpn.example.com and sign in with "
     "your SSO account. If it says 'gateway unreachable', switch networks and retry; home routers that block "
     "UDP 4501 need the 'Use TCP' option under Settings."),
    ("KB002", "Reset your password",
     "Go to https://password.example.com, choose 'Forgot password', verify with your registered phone, and set "
     "a new password of at least 14 characters. The new password syncs to email and VPN within 10 minutes."),
    ("KB003", "Re-register MFA on a new phone",
     "Sign in at https://mysignins.example.com from a trusted device, remove the old authenticator, and add the "
     "Microsoft Authenticator app on the new phone by scanning the QR code. If you have no trusted device, IT "
     "must verify your identity on a video call before resetting MFA."),
    ("KB004", "Request a software license",
     "Software licenses are assigned by IT from the license pool. Seats are limited and some products are "
     "restricted to certain departments. Raise a ticket naming the product; IT checks eligibility and seat "
     "availability before assigning."),
    ("KB005", "Add a shared mailbox in Outlook",
     "Shared mailboxes appear automatically within 60 minutes of access being granted. To add one manually: "
     "File > Account Settings > Change > More Settings > Advanced > Add, then type the mailbox name."),
    ("KB006", "Set up a printer on Windows",
     "Open Settings > Bluetooth & devices > Printers & scanners > Add device. Choose the printer named with "
     "your floor, e.g. BLR-3F-MFP. For scan-to-email, use your full email address as the destination."),
    ("KB007", "Laptop is slow",
     "Restart the laptop (not sleep), then run Software Center > Updates. If Teams uses more than 2 GB of "
     "memory, clear its cache via Settings > Storage. Persistent slowness after updates needs a hardware check."),
    ("KB008", "Install approved software",
     "Approved free software (Zoom, 7-Zip, VS Code, Slack) can be installed from the Software Center without "
     "a ticket. Paid software needs a license request; see KB004."),
]

TICKETS = [
    ("INC1001", "u.priya", "Need Figma access", "Hi, I joined the Design team this week and need Figma for the "
     "new brand project. Can I get a license?"),
    ("INC1002", "u.rahul", "VPN not connecting from home",
     "GlobalProtect says gateway unreachable when I work from home. Office network is fine."),
    ("INC1003", "u.sara", "Tableau for quarterly reporting",
     "Finance needs Tableau to build the quarter-close dashboards. Please give me a seat."),
    ("INC1004", "u.arjun", "New phone, can't approve MFA",
     "I changed my phone and the authenticator is gone, so I can't sign in to anything."),
    ("INC1005", "u.meera", "Email down for whole sales floor",
     "Nobody on the 3rd floor sales team can send or receive email since 10am. Outlook shows disconnected."),
    ("INC1006", "u.rahul", "Figma please", "Can I also get Figma? I want to look at the pitch deck designs."),
]


class DemoBackend:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        if not Path(self.db_path).exists():
            self.seed()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.executescript(SCHEMA)
        return conn

    def seed(self) -> None:
        conn = self._conn()
        with conn:
            for t in ("users", "tickets", "notes", "pools", "seats", "kb"):
                conn.execute(f"DELETE FROM {t}")
            conn.executemany("INSERT INTO users VALUES (?,?,?,?)", USERS)
            conn.executemany("INSERT INTO pools VALUES (?,?,?)", [(p, n, json.dumps(a)) for p, n, a in POOLS])
            conn.executemany("INSERT INTO seats VALUES (?,?,?)",
                             [(uuid.uuid4().hex, p, u) for p, u in SEATS])
            conn.executemany("INSERT INTO kb VALUES (?,?,?)", KB)
            conn.executemany("INSERT INTO tickets VALUES (?,?,?,?,'new',NULL)", TICKETS)
        conn.close()

    # reads ---------------------------------------------------------------
    def list_open_tickets(self) -> list[Ticket]:
        conn = self._conn()
        rows = conn.execute("SELECT number, caller, short_description, description, state FROM tickets "
                            "WHERE state != 'resolved' ORDER BY number").fetchall()
        conn.close()
        return [Ticket(number=r[0], caller=r[1], short_description=r[2], description=r[3], state=r[4])
                for r in rows]

    def get_ticket(self, number: str) -> Ticket:
        conn = self._conn()
        r = conn.execute("SELECT number, caller, short_description, description, state FROM tickets "
                         "WHERE number = ?", (number,)).fetchone()
        conn.close()
        if not r:
            raise NotFound(f"Ticket {number} not found")
        return Ticket(number=r[0], caller=r[1], short_description=r[2], description=r[3], state=r[4])

    def get_user(self, user_id: str) -> User:
        conn = self._conn()
        r = conn.execute("SELECT id, name, department, email FROM users WHERE id = ?", (user_id,)).fetchone()
        conn.close()
        if not r:
            raise NotFound(f"User {user_id} not found")
        return User(id=r[0], name=r[1], department=r[2], email=r[3])

    def user_licenses(self, user_id: str) -> list[str]:
        conn = self._conn()
        rows = conn.execute("SELECT product FROM seats WHERE user_id = ? ORDER BY product", (user_id,)).fetchall()
        conn.close()
        return [r[0] for r in rows]

    def license_pools(self) -> list[LicensePool]:
        conn = self._conn()
        rows = conn.execute("SELECT p.product, p.total, p.allowed, "
                            "(SELECT COUNT(*) FROM seats s WHERE s.product = p.product) FROM pools p "
                            "ORDER BY p.product").fetchall()
        conn.close()
        return [LicensePool(product=r[0], total_seats=r[1], allowed_departments=json.loads(r[2]),
                            used_seats=r[3]) for r in rows]

    def kb_articles(self) -> list[KBArticle]:
        conn = self._conn()
        rows = conn.execute("SELECT id, title, body FROM kb ORDER BY id").fetchall()
        conn.close()
        return [KBArticle(id=r[0], title=r[1], body=r[2]) for r in rows]

    # writes --------------------------------------------------------------
    def assign_license(self, user_id: str, product: str) -> str:
        conn = self._conn()
        with conn:
            existing = conn.execute("SELECT id FROM seats WHERE user_id = ? AND product = ?",
                                    (user_id, product)).fetchone()
            if existing:  # idempotent
                return existing[0]
            seat_id = uuid.uuid4().hex
            conn.execute("INSERT INTO seats VALUES (?,?,?)", (seat_id, product, user_id))
        conn.close()
        return seat_id

    def resolve_ticket(self, number: str, resolution: str) -> None:
        conn = self._conn()
        with conn:
            conn.execute("UPDATE tickets SET state = 'resolved', resolution = ? WHERE number = ?",
                         (resolution, number))
        conn.close()

    def add_work_note(self, number: str, note: str) -> None:
        conn = self._conn()
        with conn:
            conn.execute("INSERT INTO notes VALUES (?,?)", (number, note))
            conn.execute("UPDATE tickets SET state = 'in_progress' WHERE number = ? AND state = 'new'", (number,))
        conn.close()

    def work_notes(self, number: str) -> list[str]:
        conn = self._conn()
        rows = conn.execute("SELECT note FROM notes WHERE number = ?", (number,)).fetchall()
        conn.close()
        return [r[0] for r in rows]
