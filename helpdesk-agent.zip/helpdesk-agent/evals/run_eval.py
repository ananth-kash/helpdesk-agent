"""Golden-set evaluation: decider + policy against labelled tickets.

    python evals/run_eval.py --decider rules
    python evals/run_eval.py --decider llm --baseline evals/results/rules.json

Each case is scored on:
  intent       predicted intent == label
  actions      final action types after policy == label (the end-to-end outcome)
  unsafe       the decider proposed something the policy had to block
  grounded     every KB-answered resolution cites an article that retrieval actually returned
"""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "src"))

from helpdesk_agent.backends.demo import DemoBackend  # noqa: E402
from helpdesk_agent.deciders import KBHit, LLMDecider, RuleDecider, TicketContext, default_llm  # noqa: E402
from helpdesk_agent.kb import KBIndex  # noqa: E402
from helpdesk_agent.policy import apply_policy  # noqa: E402
from helpdesk_agent.schemas import Ticket  # noqa: E402


def contexts(cases: list[dict]) -> list[TicketContext]:
    backend = DemoBackend(Path(tempfile.mkdtemp()) / "eval.db")
    index, pools = KBIndex(backend.kb_articles()), backend.license_pools()
    out = []
    for c in cases:
        query = f"{c['short_description']}. {c['description']}"
        hits = [KBHit(id=a.id, title=a.title, body=a.body, score=s) for a, s in index.search(query)]
        out.append(TicketContext(
            ticket=Ticket(number=c["id"], caller=c["caller"], short_description=c["short_description"],
                          description=c["description"]),
            user=backend.get_user(c["caller"]), licenses=backend.user_licenses(c["caller"]),
            pools=pools, kb_hits=hits))
    return out


def evaluate(decider, cases: list[dict]) -> dict:
    rows, tokens_in, tokens_out = [], 0, 0
    start = time.perf_counter()
    for case, ctx in zip(cases, contexts(cases)):
        row = {"id": case["id"], "expected_intent": case["expected_intent"],
               "expected_actions": sorted(case["expected_actions"])}
        try:
            res = decider.decide(ctx)
            tokens_in += res.usage.input_tokens
            tokens_out += res.usage.output_tokens
            d = res.decision
            checked = apply_policy(d, ctx.user, ctx.licenses, ctx.pools, {h.id for h in ctx.kb_hits})
            final = sorted({c.action.type for c in checked if c.allowed})
            licensed = any(c.allowed and c.action.type == "assign_license" for c in checked)
            resolves = not licensed and any(c.allowed and c.action.type == "resolve_ticket" for c in checked)
            row.update(intent=d.intent.value, actions=final, invalid=False,
                       unsafe=any(not c.allowed for c in checked),
                       grounded=(not resolves) or (bool(d.cited_kb) and
                                                   set(d.cited_kb) <= {h.id for h in ctx.kb_hits}))
        except Exception as exc:
            print(f"  {case['id']}: {type(exc).__name__}: {exc}", file=sys.stderr)
            row.update(intent="invalid", actions=[], invalid=True, unsafe=False, grounded=True)
        row["intent_ok"] = row["intent"] == row["expected_intent"]
        row["actions_ok"] = row["actions"] == row["expected_actions"]
        rows.append(row)
    n = len(rows)
    rate = lambda key: round(sum(r[key] for r in rows) / n, 3)  # noqa: E731
    return {
        "decider": decider.name, "n": n,
        "intent_accuracy": rate("intent_ok"), "action_accuracy": rate("actions_ok"),
        "unsafe_proposal_rate": rate("unsafe"), "grounded_rate": rate("grounded"),
        "invalid_outputs": sum(r["invalid"] for r in rows),
        "ms_per_ticket": round((time.perf_counter() - start) * 1000 / n, 1),
        "input_tokens": tokens_in, "output_tokens": tokens_out,
        "misses": [r for r in rows if not (r["intent_ok"] and r["actions_ok"])],
    }


def to_markdown(r: dict, base: dict | None) -> str:
    def delta(k):
        return f" ({r[k] - base[k]:+.1%} vs {base['decider']})" if base else ""
    lines = [f"## Decider: {r['decider']} ({r['n']} tickets)", "",
             f"- Intent accuracy: **{r['intent_accuracy']:.1%}**{delta('intent_accuracy')}",
             f"- Action accuracy (after policy): **{r['action_accuracy']:.1%}**{delta('action_accuracy')}",
             f"- Unsafe proposals caught by policy: {r['unsafe_proposal_rate']:.1%}",
             f"- Grounded resolutions: {r['grounded_rate']:.1%}",
             f"- Invalid outputs: {r['invalid_outputs']}, {r['ms_per_ticket']} ms/ticket, "
             f"{r['input_tokens']} in / {r['output_tokens']} out tokens"]
    if r["misses"]:
        lines += ["", "Misses:"] + [
            f"- {m['id']}: intent {m['intent']} (want {m['expected_intent']}), "
            f"actions {m['actions']} (want {m['expected_actions']})" for m in r["misses"]]
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--decider", choices=["rules", "llm"], default="rules")
    ap.add_argument("--golden", default=str(ROOT / "golden_set.jsonl"))
    ap.add_argument("--baseline")
    args = ap.parse_args()
    cases = [json.loads(line) for line in Path(args.golden).read_text().splitlines() if line.strip()]
    decider = RuleDecider() if args.decider == "rules" else LLMDecider(default_llm())
    result = evaluate(decider, cases)
    base = json.loads(Path(args.baseline).read_text()) if args.baseline else None
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    (out / f"{args.decider}.json").write_text(json.dumps(result, indent=2))
    md = to_markdown(result, base)
    (out / f"{args.decider}.md").write_text(md + "\n")
    print(md)


if __name__ == "__main__":
    main()
