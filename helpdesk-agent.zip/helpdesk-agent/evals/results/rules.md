## Decider: rules (24 tickets)

- Intent accuracy: **79.2%**
- Action accuracy (after policy): **79.2%**
- Unsafe proposals caught by policy: 8.3%
- Grounded resolutions: 100.0%
- Invalid outputs: 0, 1.3 ms/ticket, 0 in / 0 out tokens

Misses:
- T04: intent other (want license_request), actions ['escalate'] (want ['assign_license', 'resolve_ticket'])
- T07: intent other (want license_request), actions ['escalate'] (want ['escalate'])
- T08: intent license_request (want license_request), actions ['assign_license', 'resolve_ticket'] (want ['escalate'])
- T10: intent incident (want how_to), actions ['escalate'] (want ['resolve_ticket'])
- T17: intent access_issue (want access_issue), actions ['resolve_ticket'] (want ['escalate'])
- T22: intent incident (want other), actions ['escalate'] (want ['escalate'])
- T24: intent how_to (want other), actions ['resolve_ticket'] (want ['escalate'])
