import json

import httpx
import mcp
import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from helpdesk_agent.backends.demo import DemoBackend
from helpdesk_agent.backends.servicenow import ServiceNowBackend
from helpdesk_agent.cli import run_queue
from helpdesk_agent.deciders import LLMDecider, RuleDecider
from helpdesk_agent.kb import KBIndex
from helpdesk_agent.mcp_server import build_server
from helpdesk_agent.policy import apply_policy
from helpdesk_agent.schemas import Action, Decision, Intent


@pytest.fixture
def backend(tmp_path):
    return DemoBackend(tmp_path / "hd.db")


@pytest.fixture
def server(backend):
    return build_server(backend)


# ------------------------------------------------------------------ retrieval

def test_kb_search_finds_the_right_article(backend):
    index = KBIndex(backend.kb_articles())
    assert index.search("GlobalProtect gateway unreachable at home")[0][0].id == "KB001"
    assert index.search("forgot my password")[0][0].id == "KB002"


# ------------------------------------------------------------------ MCP server

async def test_server_exposes_tools_resource_and_prompt(server):
    async with mcp.Client(server) as c:
        names = {t.name for t in (await c.list_tools()).tools}
        assert {"search_kb", "assign_license", "resolve_ticket", "add_work_note"} <= names
        article = await c.read_resource("kb://KB002")
        assert "password" in article.contents[0].text.lower()
        prompt = await c.get_prompt("triage_ticket", {"ticket": "T", "user": "U", "licenses": "none",
                                                      "pools": "-", "kb": "-"})
        assert "service desk" in prompt.messages[0].content.text


async def test_writes_need_a_named_approver(server):
    async with mcp.Client(server) as c:
        r = await c.call_tool("resolve_ticket", {"ticket_number": "INC1002",
                                                 "resolution": "Use the TCP option", "approved_by": " "})
        assert r.is_error and "approver" in r.content[0].text


async def test_server_reapplies_license_policy(server, backend):
    async with mcp.Client(server) as c:  # Rahul is in Sales; Figma is Design/Engineering only
        r = await c.call_tool("assign_license", {"ticket_number": "INC1006", "user_id": "u.rahul",
                                                 "product": "Figma", "approved_by": "Ananth"})
        assert r.is_error and "limited to" in r.content[0].text
        ok = await c.call_tool("assign_license", {"ticket_number": "INC1001", "user_id": "u.priya",
                                                  "product": "Figma", "approved_by": "Ananth"})
        assert not ok.is_error
    assert "Figma" in backend.user_licenses("u.priya")


# ------------------------------------------------------------------ policy

def test_policy_turns_blocked_actions_into_escalation(backend):
    user, pools = backend.get_user("u.sara"), backend.license_pools()
    d = Decision(intent=Intent.LICENSE_REQUEST, confidence=0.9, reply_to_user="You now have Tableau.",
                 actions=[Action(type="assign_license", product="Tableau", reason="asked"),
                          Action(type="resolve_ticket", reason="done")])
    checked = apply_policy(d, user, backend.user_licenses("u.sara"), pools, set())
    assert [c.allowed for c in checked] == [False, False, True]
    assert "No free Tableau seats" in checked[-1].action.reason


def test_policy_blocks_ungrounded_or_low_confidence_resolution(backend):
    user = backend.get_user("u.meera")
    d = Decision(intent=Intent.HOW_TO, confidence=0.5, reply_to_user="Try turning it off and on.",
                 cited_kb=["KB999"], actions=[Action(type="resolve_ticket", reason="guess")])
    checked = apply_policy(d, user, [], backend.license_pools(), {"KB001"})
    assert not checked[0].allowed and checked[-1].action.type == "escalate"


# ------------------------------------------------------------------ structured output

GOOD = json.dumps({"intent": "how_to", "confidence": 0.9, "reply_to_user": "Follow KB005 to add it.",
                   "cited_kb": ["KB005"], "actions": [{"type": "resolve_ticket", "reason": "answered"}]})


def _ctx_for(backend, number):
    from helpdesk_agent.deciders import KBHit, TicketContext
    t = backend.get_ticket(number)
    hits = [KBHit(id=a.id, title=a.title, body=a.body, score=s)
            for a, s in KBIndex(backend.kb_articles()).search(t.description)]
    return TicketContext(ticket=t, user=backend.get_user(t.caller), licenses=backend.user_licenses(t.caller),
                         pools=backend.license_pools(), kb_hits=hits)


def test_llm_decider_repairs_invalid_json(backend):
    model = FakeListChatModel(responses=['{"intent": "question"}', f"```json\n{GOOD}\n```"])
    out = LLMDecider(model).decide(_ctx_for(backend, "INC1002"))
    assert out.decision.intent is Intent.HOW_TO and out.usage.repairs == 1


# ------------------------------------------------------------------ agent end to end

async def test_agent_works_the_queue_with_approval(server, backend):
    result = await run_queue(RuleDecider(), server, approver="Ananth")
    by = {o["ticket"]: o for o in result["outcomes"]}
    assert by["INC1001"]["executed"] == ["assigned Figma", "resolved"]
    assert by["INC1005"]["executed"] == ["escalated"]          # incident
    assert by["INC1006"]["executed"] == ["escalated"]          # Sales can't have Figma
    assert backend.get_ticket("INC1001").state == "resolved"
    assert backend.get_ticket("INC1006").state == "in_progress"


async def test_rejected_and_edited_replies(server, backend):
    answers = iter(["e", "Ananth", "Custom reply from IT", "r", "r", "r", "r", "r"])
    result = await run_queue(RuleDecider(), server, ask=lambda _: next(answers))
    first, rest = result["outcomes"][0], result["outcomes"][1:]
    assert first["approved"] and all(not o["approved"] for o in rest)
    assert backend.get_ticket("INC1002").state == "new"        # rejected: untouched


async def test_falls_back_to_rules_when_llm_breaks(server):
    broken = LLMDecider(FakeListChatModel(responses=["nope"] * 100), max_repairs=1)
    result = await run_queue(broken, server, approver="Ananth")
    assert {o["decider"] for o in result["outcomes"]} == {"rules-fallback"}


# ------------------------------------------------------------------ ServiceNow adapter

def test_servicenow_backend_maps_table_api():
    calls = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(request)
        path = request.url.path
        if request.method == "GET" and path.endswith("/incident") and "sys_id" in request.url.params.get(
                "sysparm_fields", ""):
            return httpx.Response(200, json={"result": [{"sys_id": "abc123"}]})
        if request.method == "GET" and path.endswith("/incident"):
            return httpx.Response(200, json={"result": [{
                "number": "INC0010001", "caller_id.user_name": "abel.tuter", "short_description": "VPN",
                "description": "VPN fails", "state": "New"}]})
        if request.method == "PATCH":
            return httpx.Response(200, json={"result": {"sys_id": "abc123"}})
        return httpx.Response(404, json={"error": {}})

    sn = ServiceNowBackend("https://dev1.service-now.com", auth=("u", "p"), transport=httpx.MockTransport(handler))
    tickets = sn.list_open_tickets()
    assert tickets[0].number == "INC0010001" and tickets[0].caller == "abel.tuter"
    sn.resolve_ticket("INC0010001", "Use the TCP option in GlobalProtect")
    patch = calls[-1]
    assert patch.url.path == "/api/now/table/incident/abc123"
    assert json.loads(patch.content) == {"state": "6", "close_code": "Solution provided",
                                         "close_notes": "Use the TCP option in GlobalProtect"}
